#!/bin/bash
mkdir log
mkdir checkpoints
